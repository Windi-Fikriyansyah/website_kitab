<!DOCTYPE html>
<html lang="id" class="scroll-smooth">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Al-Kitab - Koleksi Kitab Arab Terlengkap'); ?></title>
    <?php echo $__env->yieldContent('meta'); ?>
    <link rel="preconnect" href="https://your-image-cdn.com">
    <link rel="preload" as="image" href="<?php echo e(asset('images/hero-image.jpg')); ?>">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            DEFAULT: '#1d2530',
                            50: '#f0f7ff',
                            100: '#dfcf9f',
                            200: '#dfcf9f',
                            300: '#7cc4fd',
                            400: '#36a6fa',
                            500: '#0c8aeb',
                            600: '#1d2530',
                            700: '#015dc4',
                            800: '#064e9e',
                            900: '#0b4283',
                        },
                        secondary: {
                            DEFAULT: '#6c757d',
                            50: '#f8f9fa',
                            100: '#f1f3f5',
                            200: '#e2e6ea',
                            300: '#d1d7dc',
                            400: '#aeb7c0',
                            500: '#8f9ba8',
                            600: '#6c757d',
                            700: '#495057',
                            800: '#343a40',
                            900: '#212529',
                        },
                        accent: {
                            DEFAULT: '#ffc107',
                            light: '#fff3cd',
                            dark: '#d39e00',
                        }
                    },
                    fontFamily: {
                        inter: ['Inter', 'sans-serif'],
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.5s ease-out',
                    },
                    keyframes: {
                        fadeIn: {
                            '0%': {
                                opacity: '0'
                            },
                            '100%': {
                                opacity: '1'
                            },
                        },
                        slideUp: {
                            '0%': {
                                transform: 'translateY(20px)',
                                opacity: '0'
                            },
                            '100%': {
                                transform: 'translateY(0)',
                                opacity: '1'
                            },
                        }
                    }
                }
            }
        }
    </script>

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style type="text/tailwindcss">
        @layer utilities {
            .text-shadow {
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .text-shadow-md {
                text-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
            }

            .text-shadow-lg {
                text-shadow: 0 15px 30px rgba(0, 0, 0, 0.11);
            }

            .text-shadow-none {
                text-shadow: none;
            }

            .transition-slow {
                transition: all 0.5s ease;
            }

            .bg-gradient-overlay {
                background: linear-gradient(rgba(0, 123, 255, 0.8), rgba(0, 123, 255, 0.8));
            }
        }
    </style>
</head>

<body class="font-inter antialiased text-gray-900 bg-white">
    <!-- Navigation -->
    <nav class="fixed top-0 left-0 right-0 z-50 bg-[#1d2530] shadow-sm transition-all duration-300">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center h-16 md:h-20">
                <!-- Logo -->
                <a href="<?php echo e(route('home')); ?>" class="flex items-center">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo Al-Kitab" class="h-12 w-auto">
                </a>


                <!-- Mobile menu button -->
                <div class="md:hidden">
                    <button type="button" class="text-gray-500 hover:text-gray-600 focus:outline-none"
                        aria-controls="mobile-menu" aria-expanded="false">
                        <span class="sr-only">Open main menu</span>
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>

                <!-- Desktop Menu -->
                <div class="hidden md:flex items-center space-x-1">
                    <!-- Menu Items Container -->
                    <div class="flex items-center space-x-1">
                        <!-- Beranda -->
                        <div class="relative group">
                            <a href="<?php echo e(route('home')); ?>"
                                class="px-3 py-2 text-sm font-medium text-white hover:text-gray-300 transition-colors"><?php echo e(__('messages.beranda')); ?></a>
                        </div>

                        <!-- Static Menu -->
                        <a href="<?php echo e(route('produk.semua')); ?>"
                            class="px-3 py-2 text-sm font-medium text-white hover:text-gray-300 transition-colors"><?php echo e(__('messages.produk')); ?></a>

                        <a href="<?php echo e(route('tentang')); ?>"
                            class="px-3 py-2 text-sm font-medium text-white hover:text-gray-300 transition-colors"><?php echo e(__('messages.tentang')); ?></a>
                        <a href="<?php echo e(route('kontak')); ?>"
                            class="px-3 py-2 text-sm font-medium text-white hover:text-gray-300 transition-colors"><?php echo e(__('messages.hubungi')); ?></a>
                    </div>

                    <div class="relative group ml-4">
                        <button
                            class="flex items-center px-3 py-2 text-sm font-medium text-white hover:text-gray-300 transition-colors">
                            <i class="fas fa-globe mr-2"></i>
                            <span id="current-language">ID</span>
                            <i class="fas fa-chevron-down ml-2 text-xs"></i>
                        </button>

                        <!-- Language Dropdown -->
                        <div
                            class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                            <div class="py-1">
                                <a href="<?php echo e(route('language.switch', 'id')); ?>"
                                    class="language-option flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 <?php echo e(app()->getLocale() == 'id' ? 'bg-blue-50 text-blue-600' : ''); ?>">
                                    <img src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/id.svg"
                                        alt="Indonesia" class="w-5 h-4 mr-3 rounded-sm">
                                    <div>
                                        <div class="font-medium">Indonesia</div>
                                        <div class="text-xs text-gray-500">Bahasa Indonesia</div>
                                    </div>
                                </a>

                                <a href="<?php echo e(route('language.switch', 'en')); ?>"
                                    class="language-option flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 <?php echo e(app()->getLocale() == 'en' ? 'bg-blue-50 text-blue-600' : ''); ?>">
                                    <img src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/us.svg"
                                        alt="English" class="w-5 h-4 mr-3 rounded-sm">
                                    <div>
                                        <div class="font-medium">English</div>
                                        <div class="text-xs text-gray-500">English</div>
                                    </div>
                                </a>

                                <a href="<?php echo e(route('language.switch', 'ar')); ?>"
                                    class="language-option flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 <?php echo e(app()->getLocale() == 'ar' ? 'bg-blue-50 text-blue-600' : ''); ?>">
                                    <img src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/sa.svg"
                                        alt="Arabic" class="w-5 h-4 mr-3 rounded-sm">
                                    <div>
                                        <div class="font-medium">العربية</div>
                                        <div class="text-xs text-gray-500">Arabic</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->

                </div>
            </div>
        </div>

        <!-- Kategori Menu Bar -->
        <div class="bg-[#f2f4f7]">
            <div class="container mx-auto px-4">
                <div class="hidden md:flex items-center justify-center space-x-1 py-2" id="kategori-menu-container">
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative group" data-kategori-id="<?php echo e($kategori['id']); ?>">
                            <button
                                class="px-3 py-2 text-sm font-medium text-gray-800 hover:text-primary-600 flex items-center transition-colors">
                                <?php echo e($kategori['nama_indonesia']); ?>

                                <?php if(count($kategori['subkategoris']) > 0): ?>
                                    <i class="fas fa-chevron-down ml-1 text-xs"></i>
                                <?php endif; ?>
                            </button>

                            <?php if(count($kategori['subkategoris']) > 0): ?>
                                <div
                                    class="fixed left-0 right-0 w-screen bg-white rounded-b-md shadow-xl py-1 z-10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border border-gray-200">
                                    <div class="container mx-auto px-4">
                                        <div class="flex">
                                            <!-- Kolom Subkategori (25% width) -->
                                            <div class="w-1/4 p-6 bg-gray-50">
                                                <h3 class="font-bold text-lg mb-4 text-primary-600">
                                                    <?php echo e($kategori['nama_indonesia']); ?></h3>
                                                <ul class="space-y-3">
                                                    <?php $__currentLoopData = $kategori['subkategoris']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subkategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a href=""
                                                                class="subkategori-link block px-3 py-2 hover:bg-gray-100 rounded transition-colors"
                                                                data-kategori-id="<?php echo e($kategori['id']); ?>"
                                                                data-subkategori-id="<?php echo e($subkategori['id']); ?>">
                                                                <div class="flex flex-col">
                                                                    <span
                                                                        class="font-medium"><?php echo e($subkategori['nama_arab']); ?></span>
                                                                    <span
                                                                        class="text-xs text-gray-500"><?php echo e($subkategori['nama_indonesia']); ?></span>
                                                                </div>
                                                            </a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>

                                            <!-- Kolom Produk (75% width) -->
                                            <!-- Kolom Produk (75% width) -->
                                            <div class="w-3/4 p-6">
                                                <h3 class="font-bold text-lg mb-4 text-primary-600">
                                                    <?php echo e(__('messages.produk')); ?></h3>
                                                <div id="produk-container-<?php echo e($kategori['id']); ?>"
                                                    class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                                                    <!-- Products will be loaded here automatically -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="md:hidden hidden bg-white shadow-lg rounded-b-lg" id="mobile-menu">
            <div class="px-2 pt-2 pb-3 space-y-1">
                <!-- Beranda Mobile -->
                <a href="<?php echo e(route('home')); ?>"
                    class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary-600 hover:bg-gray-50">Beranda</a>

                <!-- Dynamic Mobile Menu -->
                <?php if(isset($kategoris) && count($kategoris) > 0): ?>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative">
                            <button onclick="toggleMobileDropdown(<?php echo e($kategori['id']); ?>)"
                                class="w-full flex justify-between items-center px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary-600 hover:bg-gray-50">
                                <?php echo e($kategori['nama_arab']); ?>

                                <?php if(!empty($kategori['subkategoris']) && count($kategori['subkategoris']) > 0): ?>
                                    <i class="fas fa-chevron-down text-xs" id="icon-<?php echo e($kategori['id']); ?>"></i>
                                <?php endif; ?>
                            </button>

                            <?php if(!empty($kategori['subkategoris']) && count($kategori['subkategoris']) > 0): ?>
                                <div class="pl-4 hidden" id="dropdown-<?php echo e($kategori['id']); ?>">
                                    <?php $__currentLoopData = $kategori['subkategoris']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subkategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href=""
                                            class="block px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-primary-600 hover:bg-gray-50">
                                            <div class="flex flex-col">
                                                <span><?php echo e($subkategori['nama_arab']); ?></span>
                                                <span
                                                    class="text-xs text-gray-500"><?php echo e($subkategori['nama_indonesia']); ?></span>
                                            </div>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <!-- Static Mobile Menu -->
                <a href="<?php echo e(route('tentang')); ?>"
                    class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary-600 hover:bg-gray-50">Tentang</a>
                <a href="<?php echo e(route('kontak')); ?>"
                    class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary-600 hover:bg-gray-50">Kontak</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="pt-16 md:pt-24 lg:pt-28"> <!-- Diperbesar padding top untuk mengakomodasi menu kategori -->
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer -->
    <footer class="bg-primary-600 text-white pt-12 pb-6">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
                <!-- About Column -->
                <div>
                    <h5 class="text-xl font-bold mb-4 flex items-center">
                        <i class="fas fa-book-open mr-2"></i> Dar Ibnu Abbas (DIBAS)
                    </h5>
                    <p class="text-primary-100 mb-4"><?php echo e(__('messages.footer_des')); ?></p>
                    <div class="flex space-x-3">
                        <a href="#"
                            class="w-10 h-10 rounded-full bg-primary-500 flex items-center justify-center hover:bg-primary-400 transition-colors">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#"
                            class="w-10 h-10 rounded-full bg-primary-500 flex items-center justify-center hover:bg-primary-400 transition-colors">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#"
                            class="w-10 h-10 rounded-full bg-primary-500 flex items-center justify-center hover:bg-primary-400 transition-colors">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#"
                            class="w-10 h-10 rounded-full bg-primary-500 flex items-center justify-center hover:bg-primary-400 transition-colors">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>

                <!-- Categories Column (Dynamic dari API) -->
                <div>
                    <h5 class="text-lg font-semibold mb-4"><?php echo e(__('messages.kategori_kitab')); ?></h5>
                    <ul class="space-y-2">
                        <?php if(isset($kategoris) && count($kategoris) > 0): ?>
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="#"
                                        class="text-primary-100 hover:text-white transition-colors"><?php echo e($kategori['nama_indonesia']); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <li><a href="#" class="text-primary-100 hover:text-white transition-colors">Kitab
                                    Fiqh</a></li>
                            <li><a href="#" class="text-primary-100 hover:text-white transition-colors">Kitab
                                    Hadits</a></li>
                            <li><a href="#" class="text-primary-100 hover:text-white transition-colors">Kitab
                                    Tafsir</a></li>
                            <li><a href="#" class="text-primary-100 hover:text-white transition-colors">Kitab
                                    Aqidah</a></li>
                            <li><a href="#" class="text-primary-100 hover:text-white transition-colors">Kitab
                                    Sirah</a></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Services Column -->
                <div>
                    <h5 class="text-lg font-semibold mb-4">Layanan</h5>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-primary-100 hover:text-white transition-colors">Cara
                                Pembelian</a></li>
                        <li><a href="#"
                                class="text-primary-100 hover:text-white transition-colors">Pengiriman</a></li>
                        <li><a href="#"
                                class="text-primary-100 hover:text-white transition-colors">Pengembalian</a></li>
                        <li><a href="#" class="text-primary-100 hover:text-white transition-colors">Bantuan &
                                Refund</a></li>
                        <li><a href="#" class="text-primary-100 hover:text-white transition-colors">FAQ</a></li>
                    </ul>
                </div>

                <!-- Contact Column -->
                <div>
                    <h5 class="text-lg font-semibold mb-4"><?php echo e(__('messages.kontak_kami')); ?></h5>
                    <ul class="space-y-2">
                        <li class="flex items-start">
                            <i class="fas fa-map-marker-alt mt-1 mr-2 text-primary-200"></i>
                            <span>Jl. Masjono No. 123<br>Yogyakarta 55571</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-phone mr-2 text-primary-200"></i>
                            <span>+62 813-3456-7890</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-envelope mr-2 text-primary-200"></i>
                            <span>info@al-kitab.com</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-clock mr-2 text-primary-200"></i>
                            <span>Senin - Sabtu: 08:00 - 20:00</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-primary-500 pt-6">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <p class="text-primary-200 mb-4 md:mb-0">&copy; 2024 Al-Kitab. Semua hak cipta dilindungi.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-primary-200 hover:text-white transition-colors">Kebijakan
                            Privasi</a>
                        <a href="#" class="text-primary-200 hover:text-white transition-colors">Syarat &
                            Ketentuan</a>
                        <a href="#" class="text-primary-200 hover:text-white transition-colors">Sitemap</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- WhatsApp Float Button -->
    <a href="https://wa.me/6281334567890" target="_blank"
        class="fixed bottom-6 right-6 w-14 h-14 bg-green-500 text-white rounded-full flex items-center justify-center text-2xl shadow-lg hover:bg-green-600 transition-colors z-40">
        <i class="fab fa-whatsapp"></i>
    </a>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Update tampilan bahasa saat dropdown dibuka
            document.querySelectorAll('.language-option').forEach(option => {
                option.addEventListener('click', function(e) {
                    e.preventDefault();
                    const locale = this.getAttribute('href').split('/').pop();

                    // Kirim request untuk ganti bahasa
                    fetch(`/language/${locale}`, {
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'Accept': 'application/json'
                            },
                            credentials: 'same-origin'
                        })
                        .then(response => {
                            if (response.ok) {
                                window.location.reload();
                            }
                        })
                        .catch(error => console.error('Error:', error));
                });
            });

            // Set bahasa aktif saat load
            const currentLang = '<?php echo e(app()->getLocale()); ?>';
            document.getElementById('current-language').textContent = currentLang.toUpperCase();
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to load products by category
            function loadProdukByKategori(kategoriId) {
                const produkContainer = document.getElementById(`produk-container-${kategoriId}`);

                // Show loading state
                produkContainer.innerHTML = '<div class="col-span-full text-center py-8">Memuat produk...</div>';

                // Fetch products for this category
                fetch(`/produk-by-kategori/${kategoriId}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data && data.data.length > 0) {
                            renderProduk(data.data, produkContainer);
                        } else {
                            produkContainer.innerHTML =
                                '<div class="col-span-full text-center py-8">Tidak ada produk dalam kategori ini.</div>';
                        }
                    })
                    .catch(error => {
                        console.error('Error loading products:', error);
                        produkContainer.innerHTML =
                            '<div class="col-span-full text-center py-8">Gagal memuat produk.</div>';
                    });
            }

            // Function to load products by subcategory
            function loadProdukBySubkategori(linkElement) {
                const kategoriId = linkElement.getAttribute('data-kategori-id');
                const subkategoriId = linkElement.getAttribute('data-subkategori-id');
                const produkContainer = document.getElementById(`produk-container-${kategoriId}`);

                // Show loading state
                produkContainer.innerHTML = '<div class="col-span-full text-center py-8">Memuat produk...</div>';

                // Fetch products for this subcategory
                fetch(`/produk-by-subkategori/${subkategoriId}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data && data.data.length > 0) {
                            renderProduk(data.data, produkContainer);
                        } else {
                            produkContainer.innerHTML =
                                '<div class="col-span-full text-center py-8"><?php echo e(__('messages.not_kategori')); ?></div>';
                        }
                    })
                    .catch(error => {
                        console.error('Error loading products:', error);
                        produkContainer.innerHTML =
                            '<div class="col-span-full text-center py-8">Gagal memuat produk.</div>';
                    });
            }

            // Common function to render products
            // Common function to render products
            function renderProduk(produks, container) {
                let html = '';
                produks.forEach(produk => {
                    // Gunakan gambar pertama jika ada, jika tidak gunakan gambar default
                    const coverImage = produk.images && produk.images.length > 0 ?
                        produk.images[0] : '/images/default-book.jpg';
                    const productUrl = `/produk/${produk.id}/${produk.slug}`;
                    html += `
            <a href="${productUrl}" class="group">
                <div class="bg-white p-3 rounded-lg border border-gray-200 hover:shadow-md transition-all">
                    <div class="h-40 bg-gray-100 rounded-md mb-3 overflow-hidden">
                        <img src="${coverImage}"
                             alt="${produk.judul}"
                             class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                             onerror="this.src='/images/default-book.jpg'">
                    </div>
                    <h4 class="font-medium text-gray-800 group-hover:text-primary-600 truncate">${produk.judul}</h4>
                    <p class="text-sm text-gray-500 truncate">${produk.penulis || 'Penulis tidak diketahui'}</p>
                </div>
            </a>`;
                });
                container.innerHTML = html;
            }

            // Setup hover events for desktop menu
            document.querySelectorAll('.group[data-kategori-id]').forEach(group => {
                const kategoriId = group.getAttribute('data-kategori-id');

                group.addEventListener('mouseenter', function() {
                    loadProdukByKategori(kategoriId);
                });
            });

            // Setup mouseenter events for subcategory links
            document.querySelectorAll('.subkategori-link').forEach(link => {
                link.addEventListener('mouseenter', function(e) {
                    e.preventDefault();
                    loadProdukBySubkategori(this);
                });
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // FAQ Toggle Functionality
            const faqToggles = document.querySelectorAll('.faq-toggle');

            faqToggles.forEach(toggle => {
                toggle.addEventListener('click', function() {
                    // Get the associated content and icon
                    const content = this.nextElementSibling;
                    const icon = this.querySelector('i');

                    // Toggle the content visibility
                    content.classList.toggle('hidden');

                    // Toggle the icon
                    icon.classList.toggle('fa-chevron-down');
                    icon.classList.toggle('fa-chevron-up');

                    // Optional: Close other open FAQs when opening a new one
                    if (!content.classList.contains('hidden')) {
                        document.querySelectorAll('.faq-content').forEach(item => {
                            if (item !== content && !item.classList.contains('hidden')) {
                                item.classList.add('hidden');
                                const otherIcon = item.previousElementSibling.querySelector(
                                    'i');
                                otherIcon.classList.remove('fa-chevron-up');
                                otherIcon.classList.add('fa-chevron-down');
                            }
                        });
                    }
                });
            });

            // Contact Form Submission
            const contactForm = document.getElementById('contactForm');
            if (contactForm) {
                contactForm.addEventListener('submit', function(e) {
                    e.preventDefault();

                    // Simulate form submission
                    const submitButton = this.querySelector('button[type="submit"]');
                    submitButton.disabled = true;
                    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Mengirim...';

                    // In a real application, you would send the form data to your server here
                    setTimeout(() => {
                        submitButton.disabled = false;
                        submitButton.textContent = 'Kirim Pesan';

                        // Show success message
                        alert(
                            'Terima kasih! Pesan Anda telah berhasil dikirim. Kami akan segera menghubungi Anda.'
                        );
                        contactForm.reset();
                    }, 1500);
                });
            }
        });
    </script>
    
    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH D:\website_kitab\resources\views/layouts/app.blade.php ENDPATH**/ ?>