<?php $__env->startSection('title', $seo['title'] ?? 'Al-Kitab - Koleksi Kitab Arab Terlengkap'); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description"
        content="<?php echo e($seo['description'] ?? 'Temukan ribuan kitab Arab terbaik untuk memperdalam ilmu Islam'); ?>">
    <meta name="keywords" content="<?php echo e($seo['keywords'] ?? 'kitab arab, buku islam, fiqh, hadits, tafsir'); ?>">
    <meta name="author" content="Al-Kitab">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e($seo['canonical'] ?? url('/')); ?>">
    <meta property="og:title" content="<?php echo e($seo['title'] ?? 'Al-Kitab - Koleksi Kitab Arab Terlengkap'); ?>">
    <meta property="og:description"
        content="<?php echo e($seo['description'] ?? 'Temukan ribuan kitab Arab terbaik untuk memperdalam ilmu Islam'); ?>">
    <meta property="og:image" content="<?php echo e($seo['og_image'] ?? asset('images/og-image.jpg')); ?>">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo e($seo['canonical'] ?? url('/')); ?>">
    <meta property="twitter:title" content="<?php echo e($seo['title'] ?? 'Al-Kitab - Koleksi Kitab Arab Terlengkap'); ?>">
    <meta property="twitter:description"
        content="<?php echo e($seo['description'] ?? 'Temukan ribuan kitab Arab terbaik untuk memperdalam ilmu Islam'); ?>">
    <meta property="twitter:image" content="<?php echo e($seo['og_image'] ?? asset('images/og-image.jpg')); ?>">

    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo e($seo['canonical'] ?? url('/')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <section class="relative bg-gray-900 overflow-hidden pt-10">
        <!-- Carousel Container -->
        <div class="relative h-[600px] w-full">
            <!-- Carousel Items -->
            <div class="absolute inset-0 transition-opacity duration-1000 ease-in-out opacity-0" id="carousel-item-1">
                <div class="absolute inset-0 bg-black/50"></div>
                <img src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80"
                    alt="Kitab Arab" class="w-full h-full object-cover">
            </div>

            <div class="absolute inset-0 transition-opacity duration-1000 ease-in-out opacity-0" id="carousel-item-2">
                <div class="absolute inset-0 bg-black/50"></div>
                <img src="https://images.unsplash.com/photo-1544717305-2782549b5136?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80"
                    alt="Kitab Kuno" class="w-full h-full object-cover">
            </div>

            <div class="absolute inset-0 transition-opacity duration-1000 ease-in-out opacity-0" id="carousel-item-3">
                <div class="absolute inset-0 bg-black/50"></div>
                <img src="https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80"
                    alt="Pustaka Islam" class="w-full h-full object-cover">
            </div>

            <!-- Content Overlay -->
            <div class="absolute inset-0 flex items-center justify-center">
                <div class="container mx-auto px-4 text-center z-10">
                    <h1 class="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-4 animate-fade-in">
                        <?php echo e(__('messages.koleksi_kitab')); ?> <br>
                        <span class="text-[#fde047]"><?php echo e(__('messages.terlengkap')); ?></span>
                    </h1>
                    <p class="text-lg md:text-xl text-gray-200 max-w-2xl mx-auto mb-8 animate-fade-in">
                        <?php echo e(__('messages.deskripsi')); ?>

                    </p>

                    <div class="max-w-xl mx-auto relative animate-slide-up">
                        <input type="text"
                            class="w-full py-4 px-6 rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-primary-400"
                            placeholder="<?php echo e(__('messages.placeholder')); ?>">
                        <button
                            class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-[#ffc107] hover:bg-[#e0a800] text-gray-900 font-semibold px-8 py-2.5 rounded-full transition-all duration-300 shadow-lg">
                            <?php echo e(__('messages.cari')); ?>

                        </button>
                    </div>

                    <div
                        class="mt-12 flex flex-col md:flex-row justify-center items-center gap-6 md:gap-12 bg-white/20 backdrop-blur-sm rounded-xl p-6 max-w-4xl mx-auto animate-fade-in">
                        <div class="text-center">
                            <span class="block text-3xl font-bold text-white"><?php echo e(rand(50, 200)); ?></span>
                            <span class="text-gray-200"><?php echo e(__('messages.total_kitab')); ?></span>
                        </div>
                        <div class="text-center">
                            <span class="block text-3xl font-bold text-white"><?php echo e(rand(1000, 5000)); ?></span>
                            <span class="text-gray-200"><?php echo e(__('messages.pelanggan')); ?></span>
                        </div>
                        <div class="text-center">
                            <span class="block text-3xl font-bold text-white">4.<?php echo e(rand(5, 9)); ?></span>
                            <span class="text-gray-200"><?php echo e(__('messages.rating')); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Carousel Controls -->
            <div class="absolute bottom-8 left-0 right-0 flex justify-center space-x-2 z-10">
                <button class="carousel-control w-3 h-3 rounded-full bg-white/50 hover:bg-white transition-colors"
                    data-target="1"></button>
                <button class="carousel-control w-3 h-3 rounded-full bg-white/50 hover:bg-white transition-colors"
                    data-target="2"></button>
                <button class="carousel-control w-3 h-3 rounded-full bg-white/50 hover:bg-white transition-colors"
                    data-target="3"></button>
            </div>
        </div>
    </section>

    <!-- Featured Books Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl md:text-4xl font-bold text-center text-primary-600 mb-4">
                <?php echo e(__('messages.koleksi_terbaru')); ?></h2>
            <p class="text-center text-gray-600 max-w-2xl mx-auto mb-12">
                <?php echo e(__('messages.koleksi_deskripsi')); ?>

            </p>

            <?php if(count($produk) > 0): ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    <?php $__currentLoopData = array_slice($produk, 0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 hover:-translate-y-1">
                            <div class="bg-gradient-to-br from-gray-100 to-gray-200 h-64 relative overflow-hidden">
                                <?php if(isset($book['images']) && count($book['images']) > 1): ?>
                                    <!-- Carousel for multiple images -->
                                    <div class="product-carousel h-full w-full relative">
                                        <?php $__currentLoopData = $book['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div
                                                class="absolute inset-0 transition-opacity duration-500 ease-in-out opacity-0">
                                                <img src="<?php echo e($image); ?>" alt="<?php echo e($book['judul']); ?>"
                                                    class="w-full h-full object-contain p-4">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <!-- Carousel Controls -->
                                        <div class="absolute bottom-4 left-0 right-0 flex justify-center space-x-2 z-10">
                                            <?php $__currentLoopData = $book['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <button
                                                    class="product-carousel-control w-2 h-2 rounded-full bg-gray-400 hover:bg-gray-600 transition-colors"
                                                    data-target="<?php echo e($index); ?>"></button>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php elseif(isset($book['images'][0])): ?>
                                    <!-- Single image -->
                                    <img src="<?php echo e($book['images'][0]); ?>" alt="<?php echo e($book['judul']); ?>"
                                        class="w-full h-full object-contain p-4">
                                <?php else: ?>
                                    <!-- Fallback icon -->
                                    <i
                                        class="fas fa-book-open text-5xl text-gray-400 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></i>
                                <?php endif; ?>
                            </div>
                            <div class="p-6">
                                <span
                                    class="inline-block text-xs font-semibold uppercase tracking-wider border border-gray-300 rounded-full px-3 py-1 mb-2">
                                    <?php echo e($book['kategori'] ?? 'Kitab Islam'); ?>

                                </span>
                                <h3 class="text-lg font-semibold text-gray-800 mt-1 mb-1"><?php echo e($book['judul']); ?></h3>
                                <p class="text-sm text-gray-500 mb-3">
                                    <?php echo e($book['penulis'] ?? 'Penulis tidak diketahui'); ?>

                                </p>

                                <a href="<?php echo e(route('produk.detail', [
                                    'id' => $book['id'],
                                    'slug' => Str::slug($book['judul_indo'] ?? ($book['judul'] ?? '')),
                                ])); ?>"
                                    class="block w-full bg-[#dfcf9f] hover:bg-[#dfcf9f]/90 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center text-center">
                                    <i class="fas fa-eye mr-2"></i> Lihat Detail
                                </a>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Second Row -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-8">
                    <?php $__currentLoopData = array_slice($produk, 4, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 hover:-translate-y-1">
                            <div class="bg-gradient-to-br from-gray-100 to-gray-200 h-64 relative overflow-hidden">
                                <?php if(isset($book['images']) && count($book['images']) > 1): ?>
                                    <!-- Carousel for multiple images -->
                                    <div class="product-carousel h-full w-full relative">
                                        <?php $__currentLoopData = $book['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div
                                                class="absolute inset-0 transition-opacity duration-500 ease-in-out opacity-0">
                                                <img src="<?php echo e($image); ?>" alt="<?php echo e($book['judul']); ?>"
                                                    class="w-full h-full object-contain p-4">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <!-- Carousel Controls -->
                                        <div class="absolute bottom-4 left-0 right-0 flex justify-center space-x-2 z-10">
                                            <?php $__currentLoopData = $book['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <button
                                                    class="product-carousel-control w-2 h-2 rounded-full bg-gray-400 hover:bg-gray-600 transition-colors"
                                                    data-target="<?php echo e($index); ?>"></button>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php elseif(isset($book['images'][0])): ?>
                                    <!-- Single image -->
                                    <img src="<?php echo e($book['images'][0]); ?>" alt="<?php echo e($book['judul']); ?>"
                                        class="w-full h-full object-contain p-4">
                                <?php else: ?>
                                    <!-- Fallback icon -->
                                    <i
                                        class="fas fa-book-open text-5xl text-gray-400 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></i>
                                <?php endif; ?>
                            </div>
                            <div class="p-6">
                                <span
                                    class="inline-block text-xs font-semibold uppercase tracking-wider border border-gray-300 rounded-full px-3 py-1 mb-2">
                                    <?php echo e($book['kategori'] ?? 'Kitab Islam'); ?>

                                </span>
                                <h3 class="text-lg font-semibold text-gray-800 mt-1 mb-1"><?php echo e($book['judul']); ?></h3>
                                <p class="text-sm text-gray-500 mb-3">
                                    <?php echo e($book['penulis'] ?? 'Penulis tidak diketahui'); ?>

                                </p>

                                <a href="<?php echo e(route('produk.detail', [
                                    'id' => $book['id'],
                                    'slug' => Str::slug($book['judul_indo'] ?? ($book['judul'] ?? '')),
                                ])); ?>"
                                    class="block w-full bg-[#dfcf9f] hover:bg-[#dfcf9f]/90 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center text-center">
                                    <i class="fas fa-eye mr-2"></i> Lihat Detail
                                </a>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="text-center py-12">
                    <i class="fas fa-book-open text-5xl text-gray-400 mb-4"></i>
                    <h3 class="text-xl font-semibold text-gray-700">Produk tidak tersedia saat ini</h3>
                    <p class="text-gray-500 mt-2">Silakan coba lagi nanti</p>
                </div>
            <?php endif; ?>

            <div class="text-center mt-12">
                <a href="<?php echo e(route('produk.semua')); ?>"
                    class="border-2 border-primary-600 text-primary-600 hover:bg-primary-600 hover:text-white font-semibold py-3 px-8 rounded-full transition-colors duration-300">
                    <?php echo e(__('messages.lihat_semua_produk')); ?>

                </a>
            </div>
        </div>
    </section>

    <!-- Why Choose Al-Kitab Section -->
    <section class="bg-gray-50 py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl md:text-4xl font-bold text-center text-primary-600 mb-4">
                <?php echo e(__('messages.mengapa_memilih')); ?></h2>
            <p class="text-center text-gray-600 max-w-3xl mx-auto mb-12">
                <?php echo e(__('messages.mengapa_deskripsi')); ?>

            </p>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
                    <div
                        class="w-20 h-20 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-award text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2"><?php echo e(__('messages.kualitas_terjamin')); ?></h3>
                    <p class="text-gray-600"><?php echo e(__('messages.kualitas_terjamin_desc')); ?></p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
                    <div
                        class="w-20 h-20 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-shipping-fast text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2"><?php echo e(__('messages.pengiriman_cepat')); ?></h3>
                    <p class="text-gray-600"><?php echo e(__('messages.pengiriman_cepat_desc')); ?></p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
                    <div
                        class="w-20 h-20 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-headset text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2"><?php echo e(__('messages.pelayanan_terbaik')); ?></h3>
                    <p class="text-gray-600"><?php echo e(__('messages.pelayanan_terbaik_desc')); ?></p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
                    <div
                        class="w-20 h-20 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-certificate text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2"><?php echo e(__('messages.terpercaya')); ?></h3>
                    <p class="text-gray-600"><?php echo e(__('messages.terpercaya_desc')); ?></p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
                    <div
                        class="w-20 h-20 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-book-reader text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2"><?php echo e(__('messages.stok_lengkap')); ?></h3>
                    <p class="text-gray-600"><?php echo e(__('messages.stok_lengkap_desc')); ?></p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
                    <div
                        class="w-20 h-20 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-money-bill-wave text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2"><?php echo e(__('messages.harga_terjangkau')); ?></h3>
                    <p class="text-gray-600"><?php echo e(__('messages.harga_terjangkau_desc')); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Journey Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <div class="bg-white rounded-2xl shadow-xl p-8 md:p-12">
                <div class="text-center max-w-4xl mx-auto">
                    <h2 class="text-2xl md:text-3xl font-bold text-primary-600 mb-4"><?php echo e(__('messages.perjalanan_kami')); ?>

                    </h2>
                    <p class="text-gray-600 mb-4">
                        <?php echo e(__('messages.perjalanan_paragraf1')); ?>

                    </p>
                    <p class="text-gray-600 mb-4">
                        <?php echo e(__('messages.perjalanan_paragraf2')); ?>

                    </p>
                    <p class="text-gray-600">
                        <?php echo e(__('messages.perjalanan_paragraf3')); ?>

                    </p>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
                    <div class="bg-gray-50 rounded-xl p-6 text-center">
                        <span class="text-3xl md:text-4xl font-bold text-primary-600">25+</span>
                        <span
                            class="text-sm uppercase text-gray-500 font-semibold mt-2 block"><?php echo e(__('messages.tahun_pengalaman')); ?></span>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-6 text-center">
                        <span class="text-3xl md:text-4xl font-bold text-primary-600"><?php echo e(rand(1500, 2500)); ?>+</span>
                        <span
                            class="text-sm uppercase text-gray-500 font-semibold mt-2 block"><?php echo e(__('messages.judul_kitab')); ?></span>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-6 text-center">
                        <span class="text-3xl md:text-4xl font-bold text-primary-600"><?php echo e(rand(40, 60)); ?>K+</span>
                        <span
                            class="text-sm uppercase text-gray-500 font-semibold mt-2 block"><?php echo e(__('messages.pelanggan1')); ?></span>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-6 text-center">
                        <span class="text-3xl md:text-4xl font-bold text-primary-600">34</span>
                        <span
                            class="text-sm uppercase text-gray-500 font-semibold mt-2 block"><?php echo e(__('messages.provinsi')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Carousel functionality - defer non-critical
            setTimeout(() => {
                const items = [
                    document.getElementById('carousel-item-1'),
                    document.getElementById('carousel-item-2'),
                    document.getElementById('carousel-item-3')
                ];

                const controls = document.querySelectorAll('.carousel-control');
                let currentIndex = 0;

                // Show first item initially
                if (items[0]) {
                    items[0].classList.add('opacity-100');
                    controls[0]?.classList.remove('bg-white/50');
                    controls[0]?.classList.add('bg-white');
                }

                // Function to show specific slide
                function showSlide(index) {
                    // Hide all slides
                    items.forEach(item => {
                        item?.classList.remove('opacity-100');
                        item?.classList.add('opacity-0');
                    });

                    // Reset all controls
                    controls.forEach(control => {
                        control?.classList.remove('bg-white');
                        control?.classList.add('bg-white/50');
                    });

                    // Show selected slide
                    items[index]?.classList.remove('opacity-0');
                    items[index]?.classList.add('opacity-100');

                    // Highlight selected control
                    controls[index]?.classList.remove('bg-white/50');
                    controls[index]?.classList.add('bg-white');

                    currentIndex = index;
                }

                // Add click event to controls
                controls.forEach((control, index) => {
                    control?.addEventListener('click', () => {
                        showSlide(index);
                    });
                });

                // Auto rotate slides every 5 seconds
                if (items.length > 0) {
                    setInterval(() => {
                        const nextIndex = (currentIndex + 1) % items.length;
                        showSlide(nextIndex);
                    }, 5000);
                }
            }, 500);

            // Product carousels - load after main content
            setTimeout(() => {
                document.querySelectorAll('.product-carousel').forEach(carousel => {
                    const items = carousel.querySelectorAll('div[class*="transition-opacity"]');
                    const controls = carousel.querySelectorAll('.product-carousel-control');
                    let currentIndex = 0;

                    // Show first item initially
                    if (items.length > 0) {
                        items[0].classList.add('opacity-100');
                        controls[0]?.classList.remove('bg-gray-400');
                        controls[0]?.classList.add('bg-gray-600');
                    }

                    // Function to show specific slide
                    function showProductSlide(index) {
                        // Hide all slides
                        items.forEach(item => {
                            item?.classList.remove('opacity-100');
                            item?.classList.add('opacity-0');
                        });

                        // Reset all controls
                        controls.forEach(control => {
                            control?.classList.remove('bg-gray-600');
                            control?.classList.add('bg-gray-400');
                        });

                        // Show selected slide
                        items[index]?.classList.remove('opacity-0');
                        items[index]?.classList.add('opacity-100');

                        // Highlight selected control
                        controls[index]?.classList.remove('bg-gray-400');
                        controls[index]?.classList.add('bg-gray-600');

                        currentIndex = index;
                    }

                    // Add click event to controls
                    controls.forEach((control, index) => {
                        control?.addEventListener('click', (e) => {
                            e.stopPropagation();
                            showProductSlide(index);
                        });
                    });

                    // Auto rotate slides every 3 seconds if more than 1 image
                    if (items.length > 1) {
                        setInterval(() => {
                            const nextIndex = (currentIndex + 1) % items.length;
                            showProductSlide(nextIndex);
                        }, 3000);
                    }
                });
            }, 1000);

            // Lazy loading for images
            if ('IntersectionObserver' in window) {
                const lazyLoadObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            if (img.dataset.src) {
                                img.src = img.dataset.src;
                            }
                            lazyLoadObserver.unobserve(img);
                        }
                    });
                });

                document.querySelectorAll('img[loading="lazy"]').forEach(img => {
                    lazyLoadObserver.observe(img);
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\website_kitab\resources\views/home.blade.php ENDPATH**/ ?>