@extends('layouts.app')

@section('title', $seo['title'] ?? 'Semua Produk Kitab Arab | Al-Kitab')

@section('meta')
    <meta http-equiv="cache-control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta name="description"
        content="{{ $seo['description'] ?? 'Lihat koleksi lengkap kitab Arab kami dari berbagai disiplin ilmu Islam.' }}">
    <meta name="keywords" content="{{ $seo['keywords'] ?? 'kitab arab, buku islam, koleksi kitab, fiqh, hadits, tafsir' }}">
    <meta name="author" content="Al-Kitab">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ $seo['canonical'] ?? url('/produk') }}">
    <meta property="og:title" content="{{ $seo['title'] ?? 'Semua Produk Kitab Arab | Al-Kitab' }}">
    <meta property="og:description"
        content="{{ $seo['description'] ?? 'Lihat koleksi lengkap kitab Arab kami dari berbagai disiplin ilmu Islam.' }}">
    <meta property="og:image" content="{{ $seo['og_image'] ?? asset('images/og-image-produk.jpg') }}">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="{{ $seo['canonical'] ?? url('/produk') }}">
    <meta property="twitter:title" content="{{ $seo['title'] ?? 'Semua Produk Kitab Arab | Al-Kitab' }}">
    <meta property="twitter:description"
        content="{{ $seo['description'] ?? 'Lihat koleksi lengkap kitab Arab kami dari berbagai disiplin ilmu Islam.' }}">
    <meta property="twitter:image" content="{{ $seo['og_image'] ?? asset('images/og-image-produk.jpg') }}">

    <!-- Canonical URL -->
    <link rel="canonical" href="{{ $seo['canonical'] ?? url('/produk') }}" />
@endsection

@section('content')
    <!-- Product Listing Section -->
    <section class="py-15 pt-24">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-4 md:mb-0">{{ __('messages.semua_produk') }}</h1>

                <div class="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                    <!-- Search Box -->
                    <div class="relative w-full md:w-64">
                        <form action="{{ route('produk.semua') }}" method="GET" id="search-form">
                            <input type="text" name="search" placeholder="Cari kitab..."
                                value="{{ $searchQuery ?? '' }}"
                                class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500">
                            <div class="absolute left-3 top-2.5 text-gray-400">
                                <i class="fas fa-search"></i>
                            </div>
                            <!-- Hidden inputs to preserve filters during search -->
                            @if (!empty($selectedCategories))
                                @foreach ($selectedCategories as $category)
                                    <input type="hidden" name="categories[]" value="{{ $category }}">
                                @endforeach
                            @endif
                            @if (!empty($selectedAuthors))
                                @foreach ($selectedAuthors as $author)
                                    <input type="hidden" name="authors[]" value="{{ $author }}">
                                @endforeach
                            @endif
                            @if (!empty($selectedPublishers))
                                @foreach ($selectedPublishers as $publisher)
                                    <input type="hidden" name="publishers[]" value="{{ $publisher }}">
                                @endforeach
                            @endif
                            @if (!empty($selectedHarakat))
                                @foreach ($selectedHarakat as $harakat)
                                    <input type="hidden" name="harakat[]" value="{{ $harakat }}">
                                @endforeach
                            @endif
                            @if (!empty($selectedCovers))
                                @foreach ($selectedCovers as $cover)
                                    <input type="hidden" name="covers[]" value="{{ $cover }}">
                                @endforeach
                            @endif
                        </form>
                    </div>
                </div>
            </div>

            <div class="flex flex-col lg:flex-row gap-8">
                <!-- Sidebar Filters -->
                <div class="lg:w-1/4">
                    <div class="bg-white p-6 rounded-lg shadow-sm sticky top-4">
                        <h3 class="font-semibold text-lg mb-4 flex items-center justify-between">
                            <span>Filter Produk</span>
                            <a href="{{ route('produk.semua') }}"
                                class="text-sm text-primary-600 hover:text-primary-800">Reset</a>
                        </h3>

                        <!-- Main Filter Form -->
                        <form id="filter-form" method="GET" action="{{ route('produk.semua') }}">
                            <!-- Preserve search query -->
                            @if (!empty($searchQuery))
                                <input type="hidden" name="search" value="{{ $searchQuery }}">
                            @endif

                            <!-- Kategori Filter -->
                            <div class="mb-6">
                                <h4 class="font-medium mb-3 flex items-center justify-between cursor-pointer filter-toggle">
                                    <span>Kategori</span>
                                    <i class="fas fa-chevron-up text-xs"></i>
                                </h4>
                                <div class="filter-content">
                                    <div class="space-y-2">
                                        @foreach ($kategoris as $kategori)
                                            <div class="flex items-center">
                                                <input id="filter-category-{{ $kategori->id }}" type="checkbox"
                                                    name="categories[]" value="{{ $kategori->nama_arab }}"
                                                    class="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 filter-checkbox"
                                                    {{ in_array($kategori->nama_arab, $selectedCategories ?? []) ? 'checked' : '' }}>
                                                <label for="filter-category-{{ $kategori->id }}"
                                                    class="ml-2 text-sm text-gray-700 cursor-pointer">
                                                    {{ $kategori->nama_arab }}
                                                    @if (!empty($kategori->nama_indonesia))
                                                        <span
                                                            class="text-xs text-gray-500">({{ $kategori->nama_indonesia }})</span>
                                                    @endif
                                                </label>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>

                            <!-- Penulis Filter -->
                            <div class="mb-6">
                                <h4 class="font-medium mb-3 flex items-center justify-between cursor-pointer filter-toggle">
                                    <span>Penulis</span>
                                    <i class="fas fa-chevron-up text-xs"></i>
                                </h4>
                                <div class="filter-content space-y-2 max-h-60 overflow-y-auto">
                                    @foreach ($authors as $author)
                                        <div class="flex items-center">
                                            <input id="filter-author-{{ $author->id }}" type="checkbox" name="authors[]"
                                                value="{{ $author->nama_arab }}"
                                                class="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 filter-checkbox"
                                                {{ in_array($author->nama_arab, $selectedAuthors ?? []) ? 'checked' : '' }}>
                                            <label for="filter-author-{{ $author->id }}"
                                                class="ml-2 text-sm text-gray-700 cursor-pointer">
                                                {{ $author->nama_arab }}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>

                            <!-- Penerbit Filter -->
                            <div class="mb-6">
                                <h4
                                    class="font-medium mb-3 flex items-center justify-between cursor-pointer filter-toggle">
                                    <span>Penerbit</span>
                                    <i class="fas fa-chevron-up text-xs"></i>
                                </h4>
                                <div class="filter-content space-y-2 max-h-60 overflow-y-auto">
                                    @foreach ($publishers as $publisher)
                                        <div class="flex items-center">
                                            <input id="filter-publisher-{{ $publisher->id }}" type="checkbox"
                                                name="publishers[]" value="{{ $publisher->nama_arab }}"
                                                class="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 filter-checkbox"
                                                {{ in_array($publisher->nama_arab, $selectedPublishers ?? []) ? 'checked' : '' }}>
                                            <label for="filter-publisher-{{ $publisher->id }}"
                                                class="ml-2 text-sm text-gray-700 cursor-pointer">
                                                {{ $publisher->nama_arab }}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>

                            <!-- Harakat Filter -->
                            <div class="mb-6">
                                <h4
                                    class="font-medium mb-3 flex items-center justify-between cursor-pointer filter-toggle">
                                    <span>Harakat</span>
                                    <i class="fas fa-chevron-up text-xs"></i>
                                </h4>
                                <div class="filter-content space-y-2">
                                    @foreach ($harakatList as $haraka)
                                        <div class="flex items-center">
                                            <input id="filter-harakat-{{ $haraka->id }}" type="checkbox"
                                                name="harakat[]" value="{{ $haraka->nama_arab }}"
                                                class="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 filter-checkbox"
                                                {{ in_array($haraka->nama_arab, $selectedHarakat ?? []) ? 'checked' : '' }}>
                                            <label for="filter-harakat-{{ $haraka->id }}"
                                                class="ml-2 text-sm text-gray-700 cursor-pointer">
                                                {{ $haraka->nama_arab }}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>

                            <!-- Cover Filter -->
                            <div class="mb-6">
                                <h4
                                    class="font-medium mb-3 flex items-center justify-between cursor-pointer filter-toggle">
                                    <span>Jenis Cover</span>
                                    <i class="fas fa-chevron-up text-xs"></i>
                                </h4>
                                <div class="filter-content space-y-2">
                                    @foreach ($covers as $cover)
                                        <div class="flex items-center">
                                            <input id="filter-cover-{{ $cover->id }}" type="checkbox" name="covers[]"
                                                value="{{ $cover->nama_arab }}"
                                                class="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 filter-checkbox"
                                                {{ in_array($cover->nama_arab, $selectedCovers ?? []) ? 'checked' : '' }}>
                                            <label for="filter-cover-{{ $cover->id }}"
                                                class="ml-2 text-sm text-gray-700 cursor-pointer">
                                                {{ $cover->nama_arab }}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Product Grid -->
                <div class="lg:w-3/4">
                    @if (count($produk) > 0)
                        <!-- Product Count -->
                        <!-- Replace the product count section with this -->
                        <div class="flex justify-between items-center mb-6">
                            <p class="text-sm text-gray-600">
                                Menampilkan {{ ($page - 1) * $perPage + 1 }}-{{ min($page * $perPage, $totalProduk) }}
                                dari {{ $totalProduk }} produk
                            </p>
                        </div>

                        <!-- Product Cards Grid -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                            @foreach ($produk as $book)
                                <div
                                    class="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300 relative">
                                    <!-- Badge -->
                                    @if (isset($book['is_new']) && $book['is_new'])
                                        <div
                                            class="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full z-10">
                                            Baru
                                        </div>
                                    @endif

                                    <!-- Product Image -->
                                    <div
                                        class="bg-gradient-to-br from-gray-100 to-gray-200 h-64 flex items-center justify-center relative">
                                        @if (isset($book['images'][0]))
                                            <img src="{{ $book['images'][0] }}" alt="{{ $book['judul'] }}"
                                                loading="lazy"
                                                class="w-full h-full object-contain p-4 hover:scale-105 transition-transform duration-300">
                                        @else
                                            <i class="fas fa-book-open text-5xl text-gray-400"></i>
                                        @endif

                                        <!-- Quick View Button -->
                                        <div
                                            class="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-10 flex items-center justify-center opacity-0 hover:opacity-100 transition-all duration-300">
                                            <a href="{{ route('produk.detail', ['id' => $book['id'], 'slug' => Str::slug($book['judul_indo'] ?? ($book['judul'] ?? ''))]) }}"
                                                class="bg-white text-primary-600 font-medium py-2 px-4 rounded-full shadow-md hover:bg-primary-600 hover:text-white transition-colors">
                                                Lihat Detail
                                            </a>
                                        </div>
                                    </div>

                                    <!-- Product Details -->
                                    <div class="p-4">
                                        <div class="flex items-center justify-between mb-2">
                                            <span class="inline-block text-xs font-semibold text-primary-600">
                                                {{ $book['kategori'] ?? 'Kitab Islam' }}
                                            </span>
                                            <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                                                Stok: {{ $book['stok'] ?? 0 }}
                                            </span>
                                        </div>

                                        <h3 class="text-lg font-semibold text-gray-800 mb-1 line-clamp-2">
                                            {{ $book['judul'] }}</h3>
                                        <p class="text-sm text-gray-500 mb-2">
                                            {{ $book['penulis'] ?? 'Penulis tidak diketahui' }}</p>

                                        <!-- Action Buttons -->
                                        <div class="mt-4 flex space-x-2">
                                            <a href="{{ route('produk.detail', ['id' => $book['id'], 'slug' => Str::slug($book['judul_indo'] ?? ($book['judul'] ?? ''))]) }}"
                                                class="flex-1 bg-primary-600 hover:bg-primary-700 text-white py-2 px-4 rounded-lg transition-colors text-center text-sm">
                                                <i class="fas fa-eye mr-1"></i> Detail
                                            </a>
                                            <button
                                                class="bg-yellow-500 hover:bg-yellow-600 text-white p-2 rounded-lg transition-colors">
                                                <i class="fas fa-shopping-cart"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <!-- Pagination -->
                        <!-- In your produk.index.blade.php -->
                        <!-- Replace the existing pagination code with this improved version -->
                        @if ($totalProduk > $perPage)
                            <div class="mt-8 flex justify-center">
                                <nav class="inline-flex rounded-md shadow">
                                    @php
                                        $queryParams = request()->query();
                                        $totalPages = ceil($totalProduk / $perPage);
                                        $currentPage = $page;
                                        $startPage = max(1, $currentPage - 2);
                                        $endPage = min($totalPages, $currentPage + 2);
                                    @endphp

                                    <!-- Previous Page Link -->
                                    @if ($currentPage > 1)
                                        @php $queryParams['page'] = $currentPage - 1; @endphp
                                        <a href="{{ route('produk.semua') }}?{{ http_build_query($queryParams) }}"
                                            class="px-3 py-2 rounded-l-md border border-gray-300 bg-white text-gray-500 hover:bg-gray-50">
                                            <i class="fas fa-chevron-left"></i>
                                        </a>
                                    @endif

                                    <!-- First Page Link -->
                                    @if ($startPage > 1)
                                        @php $queryParams['page'] = 1; @endphp
                                        <a href="{{ route('produk.semua') }}?{{ http_build_query($queryParams) }}"
                                            class="px-4 py-2 border border-gray-300 bg-white text-gray-500 hover:bg-gray-50">
                                            1
                                        </a>
                                        @if ($startPage > 2)
                                            <span
                                                class="px-4 py-2 border border-gray-300 bg-white text-gray-500">...</span>
                                        @endif
                                    @endif

                                    <!-- Page Number Links -->
                                    @for ($i = $startPage; $i <= $endPage; $i++)
                                        @php $queryParams['page'] = $i; @endphp
                                        <a href="{{ route('produk.semua') }}?{{ http_build_query($queryParams) }}"
                                            class="px-4 py-2 border border-gray-300 bg-white {{ $i == $currentPage ? 'text-primary-600 font-medium bg-primary-50' : 'text-gray-500 hover:bg-gray-50' }}">
                                            {{ $i }}
                                        </a>
                                    @endfor

                                    <!-- Last Page Link -->
                                    @if ($endPage < $totalPages)
                                        @if ($endPage < $totalPages - 1)
                                            <span
                                                class="px-4 py-2 border border-gray-300 bg-white text-gray-500">...</span>
                                        @endif
                                        @php $queryParams['page'] = $totalPages; @endphp
                                        <a href="{{ route('produk.semua') }}?{{ http_build_query($queryParams) }}"
                                            class="px-4 py-2 border border-gray-300 bg-white text-gray-500 hover:bg-gray-50">
                                            {{ $totalPages }}
                                        </a>
                                    @endif

                                    <!-- Next Page Link -->
                                    @if ($currentPage < $totalPages)
                                        @php $queryParams['page'] = $currentPage + 1; @endphp
                                        <a href="{{ route('produk.semua') }}?{{ http_build_query($queryParams) }}"
                                            class="px-3 py-2 rounded-r-md border border-gray-300 bg-white text-gray-500 hover:bg-gray-50">
                                            <i class="fas fa-chevron-right"></i>
                                        </a>
                                    @endif
                                </nav>
                            </div>
                        @endif
                    @else
                        <!-- Empty State -->
                        <div class="bg-white rounded-xl shadow-sm p-12 text-center">
                            <i class="fas fa-book-open text-5xl text-gray-400 mb-4"></i>
                            <h3 class="text-xl font-semibold text-gray-700 mb-2">Produk tidak tersedia</h3>
                            <p class="text-gray-500 mb-6">Maaf, kami tidak menemukan produk yang sesuai dengan kriteria
                                Anda.</p>
                            <a href="{{ route('produk.semua') }}"
                                class="text-primary-600 hover:text-primary-800 font-medium">
                                <i class="fas fa-sync-alt mr-1"></i> Reset Filter
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Categories -->
    <section class="bg-gray-50 py-12">
        <div class="container mx-auto px-4">
            <h2 class="text-2xl font-bold text-center text-gray-900 mb-8">{{ __('messages.kategori_populer') }}</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="#" class="group relative overflow-hidden rounded-lg h-32">
                    <div
                        class="absolute inset-0 bg-gradient-to-br from-primary-600 to-primary-800 opacity-90 group-hover:opacity-100 transition-opacity">
                    </div>
                    <img src="https://images.unsplash.com/photo-1568219656418-15c329312bf1?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                        alt="Kitab Fiqh" class="w-full h-full object-cover">
                    <div class="absolute inset-0 flex items-center justify-center flex-col text-white">
                        <i class="fas fa-balance-scale text-3xl mb-2"></i>
                        <h3 class="font-bold text-lg">Kitab Fiqh</h3>
                        <span class="text-sm opacity-0 group-hover:opacity-100 transition-opacity">Lihat Semua</span>
                    </div>
                </a>

                <a href="#" class="group relative overflow-hidden rounded-lg h-32">
                    <div
                        class="absolute inset-0 bg-gradient-to-br from-primary-600 to-primary-800 opacity-90 group-hover:opacity-100 transition-opacity">
                    </div>
                    <img src="https://images.unsplash.com/photo-1544717305-2782549b5136?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                        alt="Kitab Hadits" class="w-full h-full object-cover">
                    <div class="absolute inset-0 flex items-center justify-center flex-col text-white">
                        <i class="fas fa-quote-right text-3xl mb-2"></i>
                        <h3 class="font-bold text-lg">Kitab Hadits</h3>
                        <span class="text-sm opacity-0 group-hover:opacity-100 transition-opacity">Lihat Semua</span>
                    </div>
                </a>

                <a href="#" class="group relative overflow-hidden rounded-lg h-32">
                    <div
                        class="absolute inset-0 bg-gradient-to-br from-primary-600 to-primary-800 opacity-90 group-hover:opacity-100 transition-opacity">
                    </div>
                    <img src="https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                        alt="Kitab Tafsir" class="w-full h-full object-cover">
                    <div class="absolute inset-0 flex items-center justify-center flex-col text-white">
                        <i class="fas fa-quran text-3xl mb-2"></i>
                        <h3 class="font-bold text-lg">Kitab Tafsir</h3>
                        <span class="text-sm opacity-0 group-hover:opacity-100 transition-opacity">Lihat Semua</span>
                    </div>
                </a>

                <a href="#" class="group relative overflow-hidden rounded-lg h-32">
                    <div
                        class="absolute inset-0 bg-gradient-to-br from-primary-600 to-primary-800 opacity-90 group-hover:opacity-100 transition-opacity">
                    </div>
                    <img src="https://images.unsplash.com/photo-1568219656418-15c329312bf1?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                        alt="Kitab Aqidah" class="w-full h-full object-cover">
                    <div class="absolute inset-0 flex items-center justify-center flex-col text-white">
                        <i class="fas fa-star-and-crescent text-3xl mb-2"></i>
                        <h3 class="font-bold text-lg">Kitab Aqidah</h3>
                        <span class="text-sm opacity-0 group-hover:opacity-100 transition-opacity">Lihat Semua</span>
                    </div>
                </a>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle filter sections
            document.querySelectorAll('.filter-toggle').forEach(toggle => {
                toggle.addEventListener('click', function() {
                    const content = this.nextElementSibling;
                    const icon = this.querySelector('i');

                    if (content.style.display === 'none' || content.style.display === '') {
                        content.style.display = 'block';
                        icon.classList.remove('fa-chevron-down');
                        icon.classList.add('fa-chevron-up');
                    } else {
                        content.style.display = 'none';
                        icon.classList.remove('fa-chevron-up');
                        icon.classList.add('fa-chevron-down');
                    }
                });
            });

            // Handle filter checkbox changes
            document.querySelectorAll('.filter-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    // Add loading state
                    document.body.style.cursor = 'wait';

                    // Submit the form
                    document.getElementById('filter-form').submit();
                });
            });

            // Handle search form submission
            document.getElementById('search-form').addEventListener('submit', function(e) {
                // Add loading state
                document.body.style.cursor = 'wait';
            });

            // Add cursor pointer to labels
            document.querySelectorAll('label[for^="filter-"]').forEach(label => {
                label.style.cursor = 'pointer';
            });
        });
    </script>

    <style>
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        /* Loading state */
        body[style*="cursor: wait"] * {
            pointer-events: none;
        }
    </style>
@endsection
